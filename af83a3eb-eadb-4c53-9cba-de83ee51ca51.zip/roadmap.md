# SECUREX account management
- [x] Strengthen the officer dashboard and verify administrator-only officer creation and removal, including existing-session revocation; open dashboards recheck access every 10 seconds. Verification officer access removed after testing.
- [x] Secure shared account storage, admin-only provisioning and password updates, audit history.
- [x] Polished officer directory, profile creation, password-change forms and sign-in.
- [x] Provision first administrator securely with user-supplied credentials.
- [x] Verify administrator/officer permissions, limits and end-to-end account workflow.
- [x] Continue account administration with audited disabling/reactivation, capacity checks and last-super-admin protection.

# Approved public and staff milestone
- [x] Separate public home/registration, staff login, administrator workspace and officer dashboard; enforce staff-only access on pages and every private action.
- [x] Create premium public home and details-collection pages, using the supplied references for the flow rather than exact colours/layout; retain SECUREX branding.
- [x] Build maintained location choices and citizen registration → authorized officer review → citizen status workflow.
- [x] Verify citizen submission, jurisdiction-scoped review, citizen status, and private-page access end to end.

# Before real-world registration
- [ ] Administrator must supply confirmed district, town and station coverage; synthetic verification coverage is disabled.

# Later approved milestones
- Citizen correction/resubmission and administrator-selected maintained station assignments.
- Properties and house monitoring, visits, QRT coordination, incidents and reports remain future stages, not active services.

# Current requested update
- [x] Restyle the watch-request page with citizen ID and start/end date/time fields from the reference, without claiming a live police service.
- [x] Add public-page back navigation and premium Support, Citizen sign in and Staff login buttons.
- [x] Check interrupted citizen changes and verify updated pages; nullable RPC typing corrected, existing tests pass. Correction/resubmission and reassignment are not yet end-to-end verified.
- [x] Explain secure staff credential access without revealing saved secrets.
