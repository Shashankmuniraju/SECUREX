import { describe,it,expect } from 'vitest'
import { staffDestination,canReview,registrationSchema,reviewSchema } from '@/lib/citizen-policy'
describe('Public and staff separation',() => {
 it('sends administrator roles to administrator controls',() => { expect(staffDestination(['SUPER_ADMIN'])).toBe('/admin') })
 it('sends officers to the separate officer dashboard',() => { expect(staffDestination(['POLICE_OFFICER'])).toBe('/officer') })
 it('never grants citizen roles a staff workspace',() => { expect(staffDestination(['CITIZEN'])).toBe('/staff-login') })
 it('allows review only in the same district and station',() => { expect(canReview(['POLICE_OFFICER'],{ district: 'Mysuru',station: 'Station A' },{ district: 'Mysuru',station: 'Station A' })).toBe(true) })
 it('blocks review in another district',() => { expect(canReview(['POLICE_OFFICER'],{ district: 'Mysuru',station: 'Station A' },{ district: 'Bengaluru',station: 'Station A' })).toBe(false) })
 it('blocks review in another station',() => { expect(canReview(['POLICE_OFFICER'],{ district: 'Mysuru',station: 'Station A' },{ district: 'Mysuru',station: 'Station B' })).toBe(false) })
 it('blocks citizen review permissions',() => { expect(canReview(['CITIZEN'],{ district: 'Mysuru',station: 'Station A' },{ district: 'Mysuru',station: 'Station A' })).toBe(false) })
 it('requires a recorded review reason',() => { expect(reviewSchema.safeParse({ target_id: '11111111-1111-4111-8111-111111111111',status: 'APPROVED',reason: '' }).success).toBe(false) })
 const input = { full_name: 'Test Citizen',mobile: '9876543210',location_id: '11111111-1111-4111-8111-111111111111',door_number: '1',address: 'Prototype address only',latitude: null,longitude: null,location_source: 'not_provided',location_accuracy: null,location_captured_at: null,password: 'Test-Only-Safe123!',consent: true }
 it('requires explicit citizen consent',() => { expect(registrationSchema.safeParse({ ...input,consent: false }).success).toBe(false) })
 it('permits registration without location tracking',() => { expect(registrationSchema.safeParse(input).success).toBe(true) })
 it('rejects a single coordinate',() => { expect(registrationSchema.safeParse({ ...input,latitude: 12 }).success).toBe(false) })
})
