import { z } from 'zod'

export const OFFICER_LIMIT = 50
export const ADMIN_LIMIT = 5
export function isStaffSessionValid(account: { enabled: boolean; session_version: number } | null | undefined, version: number | undefined) {
  return Boolean(account?.enabled && version !== undefined && account.session_version === version)
}
export function hasStaffRole(roles: string[]) { return roles.some(role => ['POLICE_OFFICER', 'ADMINISTRATOR', 'SUPER_ADMIN'].includes(role)) }
export const loginIdSchema = z.string().trim().min(3).max(40).regex(/^[a-zA-Z0-9-]+$/, 'Use letters, numbers and hyphens').transform(value => value.toUpperCase())
export const passwordSchema = z.string().min(12, 'Use at least 12 characters').max(72).regex(/[A-Z]/, 'Include an uppercase letter').regex(/[a-z]/, 'Include a lowercase letter').regex(/[0-9]/, 'Include a number').regex(/[^a-zA-Z0-9]/, 'Include a symbol')
export const officerSchema = z.object({ login_id: loginIdSchema, full_name: z.string().trim().min(2).max(100), email: z.union([z.string().email(), z.literal('')]), rank: z.string().trim().min(2).max(80), district: z.string().trim().min(2).max(80), station: z.string().trim().min(2).max(120), password: passwordSchema, reason: z.string().trim().min(5).max(500) })
export function isAdministrator(roles: string[]) { return roles.some(role => role === 'ADMINISTRATOR' || role === 'SUPER_ADMIN') }
export function requireAdministrator(roles: string[]) { if (!isAdministrator(roles)) throw new Error('Administrator access required') }
export function hasCapacity(role: string, active: number) { return active < (role === 'POLICE_OFFICER' ? OFFICER_LIMIT : ADMIN_LIMIT) }
export const accountStatusSchema = z.object({ target_id: z.string().uuid(), enabled: z.boolean(), reason: z.string().trim().min(5).max(500) })
export function requireStatusChangeAllowed(input: { actorRoles: string[]; targetRoles: string[]; currentlyEnabled: boolean; enabled: boolean; activeSuperAdmins: number; activeOfficers: number; activeAdmins: number }) {
  requireAdministrator(input.actorRoles)
  if (input.currentlyEnabled === input.enabled) throw new Error('Account already has this status')
  if (!input.enabled && input.targetRoles.includes('SUPER_ADMIN') && input.activeSuperAdmins <= 1) throw new Error('The last enabled super administrator must remain active')
  if (input.enabled && input.targetRoles.includes('POLICE_OFFICER') && !hasCapacity('POLICE_OFFICER', input.activeOfficers)) throw new Error('The 50 active officer limit has been reached')
  if (input.enabled && isAdministrator(input.targetRoles) && !hasCapacity('ADMINISTRATOR', input.activeAdmins)) throw new Error('The 5 active administrator limit has been reached')
}