import { createServerFn } from '@tanstack/react-start'
import { setResponseHeader, getRequestIP } from '@tanstack/react-start/server'
import { z } from 'zod'
import { compare, hash } from 'bcryptjs'
import { currentStaff, staffSession } from './staff.server'
import { isAdministrator, hasStaffRole, loginIdSchema, officerSchema, passwordSchema, accountStatusSchema, requireStatusChangeAllowed } from './staff-policy'

export const getStaffIdentity = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control', 'no-store')
  const me = await currentStaff()
  return me ? { id: me.id, full_name: me.full_name, roles: me.roles } : null
})

export const getStaffWorkspace = createServerFn({ method: 'GET' }).handler(async () => {
  setResponseHeader('Cache-Control', 'no-store')
  const me = await currentStaff(true)
  if (!me) return { me: null, accounts: [], audit: [] }
  if (!isAdministrator(me.roles)) return { me, accounts: [me], audit: [] }
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const [accounts, audit, roles] = await Promise.all([
    supabaseAdmin.from('staff_accounts').select('id,login_id,full_name,rank,district,station,email,enabled,created_at,password_changed_at').order('created_at', { ascending: false }),
    supabaseAdmin.from('account_audit').select('id,actor_id,target_id,action,reason,created_at').order('created_at', { ascending: false }).limit(100),
    supabaseAdmin.from('staff_roles').select('user_id,role'),
  ])
  if (accounts.error || audit.error || roles.error) throw new Error('Unable to load staff records')
  return { me, accounts: (accounts.data ?? []).map(account => ({ ...account, roles: (roles.data ?? []).filter(role => role.user_id === account.id).map(role => role.role) })), audit: audit.data ?? [] }
})
export const signInStaff = createServerFn({ method: 'POST' }).inputValidator(data => z.object({ login_id: loginIdSchema, password: z.string().min(1).max(72) }).parse(data)).handler(async ({ data }) => {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const ip = getRequestIP() ?? 'unknown'
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`${ip}:${data.login_id}`))
  const key = Array.from(new Uint8Array(digest)).map(n => n.toString(16).padStart(2, '0')).join('')
  const { data: allowed, error: throttleError } = await supabaseAdmin.rpc('staff_login_throttle', { p_key: key })
  if (throttleError || !allowed) return { ok: false, error: 'Too many attempts. Please try again in 15 minutes.' }
  const { data: account, error } = await supabaseAdmin.from('staff_accounts').select('id,password_hash,enabled,session_version').eq('login_id', data.login_id).maybeSingle()
  if (error) return { ok: false, error: 'Sign-in is temporarily unavailable.' }
  if (!account?.enabled || !(await compare(data.password, account.password_hash))) return { ok: false, error: 'Incorrect ID or password, or account unavailable.' }
  const { data: roles, error: roleError } = await supabaseAdmin.from('staff_roles').select('role').eq('user_id', account.id)
  if (roleError || !hasStaffRole((roles ?? []).map(row => row.role))) return { ok: false, error: 'Incorrect ID or password, or account unavailable.' }
  const session = await staffSession()
  await session.update({ accountId: account.id, version: account.session_version })
  return { ok: true, error: '' }
})
export const signOutStaff = createServerFn({ method: 'POST' }).handler(async () => { const session = await staffSession(); await session.clear(); return { ok: true } })
export const createOfficer = createServerFn({ method: 'POST' }).inputValidator(data => officerSchema.parse(data)).handler(async ({ data }) => {
  const actor = await currentStaff(true)
  if (!actor) throw new Error('Please sign in as an administrator')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { error } = await supabaseAdmin.rpc('provision_staff', { p_actor: actor.id, p_login: data.login_id, p_name: data.full_name, p_email: data.email, p_rank: data.rank, p_district: data.district, p_station: data.station, p_hash: await hash(data.password, 12), p_role: 'POLICE_OFFICER', p_reason: data.reason })
  if (error) return { ok: false, error: error.code === '23505' ? 'This officer ID is already in use.' : error.message.includes('capacity') ? 'The 50 active officer limit has been reached.' : 'Unable to create the officer. Please try again.' }
  return { ok: true, error: '' }
})
export const changeStaffPassword = createServerFn({ method: 'POST' }).inputValidator(data => z.object({ target_id: z.string().uuid(), password: passwordSchema, reason: z.string().trim().min(5).max(500) }).parse(data)).handler(async ({ data }) => {
  const actor = await currentStaff(true)
  if (!actor) throw new Error('Please sign in as an administrator')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const { error } = await supabaseAdmin.rpc('change_staff_password', { p_actor: actor.id, p_target: data.target_id, p_hash: await hash(data.password, 12), p_reason: data.reason })
  if (error) return { ok: false, error: 'Unable to change the password. Please try again.' }
  return { ok: true, error: '' }
})
export const setStaffEnabled = createServerFn({ method: 'POST' }).inputValidator(data => accountStatusSchema.parse(data)).handler(async ({ data }) => {
  const actor = await currentStaff(true)
  if (!actor) throw new Error('Please sign in as an administrator')
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const [accounts, roles] = await Promise.all([supabaseAdmin.from('staff_accounts').select('id,enabled'), supabaseAdmin.from('staff_roles').select('user_id,role')])
  if (accounts.error || roles.error) return { ok: false, error: 'Unable to verify account status.' }
  const target = accounts.data.find(account => account.id === data.target_id)
  if (!target) return { ok: false, error: 'Account not found.' }
  const activeIds = new Set(accounts.data.filter(account => account.enabled).map(account => account.id))
  const activeRoles = roles.data.filter(role => activeIds.has(role.user_id))
  try {
    requireStatusChangeAllowed({ actorRoles: actor.roles, targetRoles: roles.data.filter(role => role.user_id === target.id).map(role => role.role), currentlyEnabled: target.enabled, enabled: data.enabled, activeSuperAdmins: new Set(activeRoles.filter(role => role.role === 'SUPER_ADMIN').map(role => role.user_id)).size, activeOfficers: new Set(activeRoles.filter(role => role.role === 'POLICE_OFFICER').map(role => role.user_id)).size, activeAdmins: new Set(activeRoles.filter(role => isAdministrator([role.role])).map(role => role.user_id)).size })
  } catch (error) { return { ok: false, error: error instanceof Error ? error.message : 'Account status change is not allowed.' } }
  const { error } = await supabaseAdmin.rpc('set_staff_enabled', { p_actor: actor.id, p_target: data.target_id, p_enabled: data.enabled, p_reason: data.reason })
  if (error) {
    const safeMessages = ['The last enabled super administrator must remain active', 'The 50 active officer limit has been reached', 'The 5 active administrator limit has been reached', 'Account already has this status']
    return { ok: false, error: safeMessages.find(message => error.message.includes(message)) ?? 'Unable to change account status. Refresh and try again.' }
  }
  return { ok: true, error: '' }
})