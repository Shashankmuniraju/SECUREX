import { useSession } from '@tanstack/react-start/server'
import { supabaseAdmin } from '@/integrations/supabase/client.server'
import { requireAdministrator, isStaffSessionValid, hasStaffRole } from './staff-policy'

export async function staffSession() {
  const secret = process.env['SECUREX_SESSION_SECRET']
  if (!secret) throw new Error('Secure account sessions are not configured')
  return useSession<{ accountId?: string; version?: number }>({ name: 'securex-staff', password: secret, maxAge: 60 * 60 * 8, cookie: { httpOnly: true, secure: true, sameSite: 'none', partitioned: true, path: '/' } })
}
export async function currentStaff(adminOnly = false) {
  const session = await staffSession()
  if (!session.data.accountId) return null
  const { data: account, error } = await supabaseAdmin.from('staff_accounts').select('id,login_id,full_name,rank,district,station,email,enabled,session_version,created_at,password_changed_at').eq('id', session.data.accountId).maybeSingle()
  if (error) throw new Error('Unable to verify account access')
  if (!account || !isStaffSessionValid(account, session.data.version)) { await session.clear(); return null }
  const { data: rows, error: roleError } = await supabaseAdmin.from('staff_roles').select('role').eq('user_id', account.id)
  if (roleError) throw new Error('Unable to verify account permissions')
  const roles = (rows ?? []).map(row => row.role)
  if (!hasStaffRole(roles)) { await session.clear(); return null }
  if (adminOnly) requireAdministrator(roles)
  return { ...account, roles }
}