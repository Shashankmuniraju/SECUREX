# SECUREX — next-stage plan

## Already completed
- Secure staff sign-in and administrator-issued officer IDs and passwords.
- Administrator-only password changes, officer disabling and reactivation.
- Recorded reasons and action history, active-account limits, and protection for the last enabled super administrator.

## 0. Separate public services from protected staff workspaces — build first
- Build a premium public services page using your first reference for the flow: prominent SECUREX house/key identity, Register, Request Police Watch, user-ID assistance, support and privacy policy. Treat the screenshot as inspiration, not an exact visual copy.
- Use crisp white and light-gray surfaces, charcoal headings, blue primary actions and emerald location/confirmation accents with Manrope typography. Keep public pages welcoming and spacious; keep staff workspaces dense and scannable with the existing deep-navy navigation.
- Use SECUREX identity instead of the reference's AP Police name or logo; keep a discreet prototype notice.
- Add a separate **Staff login** page using administrator-issued IDs and passwords, with no public officer signup or self-service staff password reset.
- Send signed-in administrators to the administrator workspace and signed-in officers to a distinct officer dashboard.
- Public visitors opening either private address directly must be sent to staff login without receiving private records or seeing the dashboard.
- Validate the encrypted staff session, enabled status, session version and required role on every private read and action. Citizens cannot gain staff access through citizen sign-in.
- Preserve existing administrator account controls; officers cannot open administrator controls.
- Start the officer dashboard with the registration-review queue, own profile, notifications, action history and sign-out; add monitoring, visits and QRT sections as their working features are delivered.

## 1. District, town and station directory
- Add maintained Karnataka district, town and police-station records.
- Connect town choices to the selected district and officer assignments to maintained station records.
- Use verified sources or administrator-entered records; never invent official stations or totals. Mark unverified entries clearly.

## 2. Citizen registration and officer review — first complete new workflow
- Use your second reference's field flow for details collection: name, mobile, district, town, door number, address and paired coordinates, with clear **GET MY CURRENT LOCATION** and **REGISTER** actions. Upgrade the presentation with readable labels, polished fields, clear validation and a comfortable phone layout; centre the form on larger screens.
- Include required password confirmation and consent fields in the same premium visual system.
- Add optional, permission-based current-location capture with coordinates, accuracy and capture time; handle denial and allow clearly identified manual entry.
- Save the registration, generate a unique citizen ID and reference, and show confirmation with **PENDING** status.
- Give authorized officers a review queue and an in-app notification for new submissions.
- Require a recorded review action and reason for approval, rejection or correction requests; enforce jurisdiction restrictions.
- Add citizen sign-in and a page to read registration status and citizen-visible reviewer remarks.
- Keep officer password changes administrator-only; citizen security must never offer a way to reset staff credentials.

## 3. Citizen properties and house-monitoring requests
- Let approved citizens register properties and request monitoring with dates, reason and instructions.
- Show request references, status, notifications and history to the citizen.
- Let authorized officers review requests and assign eligible officers within their jurisdiction.

## 4. Officer operations and visit records
- Build an operations overview using stored records, not sample counters.
- Show pending requests, monitored houses, assigned tasks and houses awaiting visits.
- Add scheduling, visit outcomes, meaningful action descriptions, follow-up dates and permanent visit history.
- Show permitted property locations on a map without continuous citizen tracking.

## 5. QRT teams and assignments
- Add team records, availability and jurisdiction-based selection.
- Support assignment, reassignment and cancellation with reasons and history.
- Prevent conflicting assignments and update team availability consistently.
- Clearly label this as prototype team coordination, not real emergency dispatch.

## 6. Incidents, complaints, notifications and reports
- Add citizen incident reports and complaints, with optional evidence.
- Add officer assignment, status updates and citizen-visible responses.
- Finish notifications, searchable action history and permission-controlled reports.

## Quality checks for every stage
- Test each new permission, account limit and status-change rule.
- Verify complete citizen and officer workflows using saved records.
- Check phone and desktop layouts, failed submissions, empty states and privacy boundaries.
- Preserve existing account controls and audit history throughout.
- Test direct private-page access while signed out, citizen attempts to access staff pages, officer attempts to access administrator controls, session revocation and sign-out followed by browser Back.

## Technical approach
- Extend the existing React/TanStack Start app and Lovable Cloud storage rather than replacing the working staff system.
- Keep authorization on the server and staff roles separate from account profiles.
- Use database transactions for decisions, assignments and their history; store authenticated actors and server timestamps.
- Use separate pages for citizen services, officer operations and administrator controls.
- Build a phone-friendly website in this project; a separately installable native mobile app is not part of this implementation.

## Delivery order
Start with **stage 0**: premium public pages inspired by your references, separate staff login and protected administrator/officer workspaces. Then complete **stages 1–2**, delivering registration → officer review → citizen status before house monitoring or QRT work. Wire Request Police Watch to its working request flow in stage 3; never show a false submission success before that flow exists. Stages 3–6 follow as separate verified milestones; this plan does not claim official police integration or emergency response.