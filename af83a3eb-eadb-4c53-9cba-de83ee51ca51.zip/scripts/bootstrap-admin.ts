import { createClient } from '@supabase/supabase-js'
import { hash } from 'bcryptjs'
import { loginIdSchema, passwordSchema } from '../src/lib/staff-policy'

const url = process.env['SUPABASE_URL']
const key = process.env['SUPABASE_SERVICE_ROLE_KEY']
if (!url || !key) throw new Error('Cloud connection unavailable')
const client = createClient(url, key, { auth: { persistSession: false }, global: { fetch: (input, init) => { const headers = new Headers(init?.headers); if (key.startsWith('sb_')) headers.delete('Authorization'); headers.set('apikey', key); return fetch(input, { ...init, headers }) } } })
const { count, error: countError } = await client.from('staff_accounts').select('id', { count: 'exact', head: true })
if (countError) throw new Error('Unable to check administrator setup')
if (count) { console.log('Administrator setup already completed.'); process.exit(0) }
const idResult = loginIdSchema.safeParse(process.env['SECUREX_INITIAL_ADMIN_ID'])
const passwordResult = passwordSchema.safeParse(process.env['SECUREX_INITIAL_ADMIN_PASSWORD'])
if (!idResult.success || !passwordResult.success) throw new Error('Initial administrator ID/password do not meet the required format. Update the secure administrator settings.')
const { error } = await client.rpc('provision_staff', { p_actor: null, p_login: idResult.data, p_name: 'SECUREX Administrator', p_email: '', p_rank: 'Super Administrator', p_district: '', p_station: '', p_hash: await hash(passwordResult.data, 12), p_role: 'SUPER_ADMIN', p_reason: 'Secure one-time administrator provisioning' })
if (error) throw new Error('Administrator provisioning failed')
console.log('Initial administrator created securely.')