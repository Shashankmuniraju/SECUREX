import { createClient } from '@supabase/supabase-js'
import { hash } from 'bcryptjs'
import { passwordSchema } from '../src/lib/staff-policy'

const url = process.env['SUPABASE_URL']
const key = process.env['SUPABASE_SERVICE_ROLE_KEY']
if (!url || !key) throw new Error('Cloud connection unavailable')
const client = createClient(url, key, { auth: { persistSession: false }, global: { fetch: (input, init) => { const headers = new Headers(init?.headers); if (key.startsWith('sb_')) headers.delete('Authorization'); headers.set('apikey', key); return fetch(input, { ...init, headers }) } } })

const passwordResult = passwordSchema.safeParse(process.env['SECUREX_INITIAL_ADMIN_PASSWORD'])
if (!passwordResult.success) throw new Error('New administrator password does not meet the required format. Update the secure administrator settings.')

const { data: admins, error: roleError } = await client.from('staff_roles').select('user_id').eq('role', 'SUPER_ADMIN')
if (roleError || !admins?.length) throw new Error('No administrator account found')
const { data: accounts, error: accountError } = await client.from('staff_accounts').select('id,enabled').in('id', admins.map(row => row.user_id))
if (accountError || !accounts?.length) throw new Error('No administrator account found')
const target = accounts.find(account => account.enabled) ?? accounts[0]

const { error } = await client.rpc('change_staff_password', { p_actor: target.id, p_target: target.id, p_hash: await hash(passwordResult.data, 12), p_reason: 'Administrator-initiated secure password recovery' })
if (error) throw new Error('Password reset failed')
console.log('Administrator password reset securely. Sign in with your administrator ID and the new password.')
