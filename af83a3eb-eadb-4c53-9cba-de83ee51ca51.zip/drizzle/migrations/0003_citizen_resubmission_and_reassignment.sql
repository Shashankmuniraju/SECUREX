ALTER TABLE public.citizen_registrations ADD COLUMN version integer NOT NULL DEFAULT 1;
ALTER TABLE public.citizen_registrations ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();

CREATE TABLE public.registration_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_id uuid NOT NULL REFERENCES public.citizen_registrations(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES public.staff_accounts(id),
  event text NOT NULL CHECK (event IN ('RESUBMITTED','STATION_REASSIGNED')),
  detail text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX registration_events_registration_idx ON public.registration_events (registration_id, created_at DESC);
GRANT SELECT, INSERT ON public.registration_events TO service_role;
ALTER TABLE public.registration_events ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.resubmit_citizen_registration(
  p_citizen uuid,
  p_location uuid,
  p_door text,
  p_address text,
  p_lat double precision,
  p_lng double precision,
  p_source text,
  p_accuracy double precision,
  p_captured timestamptz
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r public.citizen_registrations%ROWTYPE;
  loc public.service_locations%ROWTYPE;
BEGIN
  PERFORM pg_advisory_xact_lock(701002);
  SELECT * INTO r FROM public.citizen_registrations WHERE id = p_citizen FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'registration_not_found'; END IF;
  IF r.status NOT IN ('REJECTED','CORRECTION_REQUESTED') THEN RAISE EXCEPTION 'status_not_editable'; END IF;
  SELECT * INTO loc FROM public.service_locations WHERE id = p_location AND enabled;
  IF NOT FOUND THEN RAISE EXCEPTION 'location_unavailable'; END IF;
  IF char_length(trim(p_door)) < 1 OR char_length(trim(p_door)) > 80 THEN RAISE EXCEPTION 'invalid_door'; END IF;
  IF char_length(trim(p_address)) < 10 OR char_length(trim(p_address)) > 500 THEN RAISE EXCEPTION 'invalid_address'; END IF;
  IF (p_lat IS NULL) <> (p_lng IS NULL) THEN RAISE EXCEPTION 'invalid_coordinates'; END IF;
  IF p_source NOT IN ('not_provided','manual','device') THEN RAISE EXCEPTION 'invalid_source'; END IF;
  UPDATE public.citizen_registrations SET
    location_id = p_location, door_number = trim(p_door), address = trim(p_address),
    latitude = p_lat, longitude = p_lng, location_source = p_source,
    location_accuracy = p_accuracy, location_captured_at = p_captured,
    status = 'PENDING', reviewer_remarks = NULL, reviewed_by = NULL, reviewed_at = NULL,
    version = version + 1, updated_at = now()
  WHERE id = p_citizen;
  INSERT INTO public.registration_events (registration_id, actor_id, event, detail)
  VALUES (p_citizen, NULL, 'RESUBMITTED', 'Citizen corrected and resubmitted the registration.');
END;
$$;
REVOKE ALL ON FUNCTION public.resubmit_citizen_registration(uuid,uuid,text,text,double precision,double precision,text,double precision,timestamptz) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.resubmit_citizen_registration(uuid,uuid,text,text,double precision,double precision,text,double precision,timestamptz) TO service_role;

CREATE OR REPLACE FUNCTION public.reassign_registration_station(
  p_actor uuid,
  p_version integer,
  p_target uuid,
  p_location uuid,
  p_reason text
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  a public.staff_accounts%ROWTYPE;
  r public.citizen_registrations%ROWTYPE;
  loc public.service_locations%ROWTYPE;
BEGIN
  PERFORM pg_advisory_xact_lock(701003);
  IF char_length(trim(p_reason)) < 5 OR char_length(trim(p_reason)) > 500 THEN RAISE EXCEPTION 'invalid_reason'; END IF;
  SELECT * INTO a FROM public.staff_accounts WHERE id = p_actor FOR UPDATE;
  IF NOT FOUND OR NOT a.enabled OR a.session_version <> p_version THEN RAISE EXCEPTION 'actor_invalid'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.staff_roles WHERE user_id = p_actor AND role IN ('ADMINISTRATOR','SUPER_ADMIN')) THEN RAISE EXCEPTION 'not_administrator'; END IF;
  SELECT * INTO r FROM public.citizen_registrations WHERE id = p_target FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'registration_not_found'; END IF;
  SELECT * INTO loc FROM public.service_locations WHERE id = p_location AND enabled;
  IF NOT FOUND THEN RAISE EXCEPTION 'location_unavailable'; END IF;
  IF r.location_id = p_location THEN RAISE EXCEPTION 'no_change'; END IF;
  UPDATE public.citizen_registrations SET location_id = p_location, version = version + 1, updated_at = now() WHERE id = p_target;
  INSERT INTO public.registration_events (registration_id, actor_id, event, detail)
  VALUES (p_target, p_actor, 'STATION_REASSIGNED', 'Reassigned to ' || loc.district || ' / ' || loc.town || ' / ' || loc.station || '. Reason: ' || trim(p_reason));
  INSERT INTO public.account_audit (actor_id, target_id, action, reason)
  VALUES (p_actor, p_target, 'REGISTRATION_STATION_REASSIGNED', trim(p_reason));
END;
$$;
REVOKE ALL ON FUNCTION public.reassign_registration_station(uuid,integer,uuid,uuid,text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reassign_registration_station(uuid,integer,uuid,uuid,text) TO service_role;